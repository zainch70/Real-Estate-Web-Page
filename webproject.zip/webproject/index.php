<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Real Estate Management System</title>

    <style>
        @media screen and (min-width: 1150px) {
            body {
                background-image: url("home.jpg");
                background-size: cover;
            }

            .bodyinflex {
                display: flex;
                align-items: center;
                justify-content: center;
                height: 500px;
            }

            table a {
                text-decoration: none;
                color: rgb(63, 77, 73);
            }

            table a:hover {
                text-decoration: none;
                border: 2px solid rgb(63, 77, 73);
                color: rgb(63, 77, 73);
                font-size: 17px;
                background-color: white;
            }

            input {
                background-color: rgb(63, 77, 73);
                color: white;
            }

            #login {
                border: 2px solid rgb(63, 77, 73);
            }

            h2 {
                text-align: center;
                color: white;
                background-color: rgb(63, 77, 73);
                transition: 0.9s;
            }

            h2:hover {
                text-align: center;
                color: rgb(63, 77, 73);
                background-color: whitesmoke;
                border: 0.5px solid black;
            }

            /* @media screen and (max-width: 1150px) { */
        }

        @media screen and (min-width: 1150px) {
            #vis {
                display: none;
            }
        }

        @media screen and (max-width: 1149px) {
            #vis {
                display: block;
                text-align: center;
                height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
                padding: 10px;
            }

            h2 {
                display: none;
            }

            .bodyinflex {
                display: none;
            }
        }
    </style>
</head>

<body>
    <h1 id="vis"><span>Website is visisble only to laptops screens and not responsive yet</span></h1>
    <h2>Real Estate Management System</h2>
    <div class="bodyinflex">
        <form action="index.php" method="POST">
            <div id="login">
                <table>
                    <tbody>
                        <tr>
                            <td>Username</td>
                            <td><input type="email" placeholder="abc@gmail.com" name="username" required></td>
                        </tr>
                        <tr>
                            <td>Password</td>
                            <td><input type="password" placeholder="Enter Password" name="password" required></td>
                        </tr>

                        <tr>
                            <td><input type="submit" value="Login"></td>
                            <td><a href="signup.php">Signup</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </form>
    </div>

    <?php

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        session_start();

        $connection = new mysqli("localhost", "root", "", "webproject");

        $user = $_POST["username"];
        $passw = $_POST["password"];

        $q = "select * from user where stdname='$user' and stdpassword='$passw'";
        $result = $connection->query($q);

        $row = $result->fetch_assoc();
        // $_SESSION["stdid"]=$row["stdid"];
        if ($result->num_rows > 0) {
            $_SESSION["stdid"] = $row["stdid"];

            header("Location: dashboard.html");
            exit();
        } else {
            echo "<script>alert('Enter Valid Username and Password Or Signup First to login');</script>";
        }
        $connection->close();
    }
    ?>

</body>

</html>