<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SignUp</title>

    <style>
        h2 {
            text-align: center;
            color: white;
            background-color: rgb(63, 77, 73);
            transition: 0.9s;
        }

        h2:hover {
            text-align: center;
            color: rgb(63, 77, 73);
            background-color: whitesmoke;
            border: 0.5px solid black;
        }

        table {
            background-color: white;
            color: rgb(63, 77, 73);
            height: 200px;
            width: 70%;
            transition: 1s;
        }

        table:hover {
            background-color: rgb(63, 77, 73);
            color: white;
            height: 200px;
            width: 70%;
        }

        td input {
            height: 40px;
            width: 75%;
        }

        td #substyle {
            margin-left: 55%;
            width: 10%;
        }
    </style>
</head>

<body>
    <h2>Sign Up Below</h2>
    <form action="signup.php" method="POST">
        <table border="1">
            <tbody>
                <tr>
                    <td>Username</td>
                    <td><input type="email" name="stdname" placeholder="Enter Username" required></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td><input type="password" name="stdpassword" placeholder="Enter Password" required></td>
                </tr>
                <tr>
                    <td>Confirm Password</td>
                    <td><input type="password" name="stdcpassword" placeholder="Confirm Password" required></td>
                </tr>
                <tr>
                    <td colspan="2"><input type="submit" value="Submit" id="substyle"></td>
                </tr>
            </tbody>
        </table>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST["stdname"];
        $password = $_POST["stdpassword"];
        $cpassword = $_POST["stdcpassword"];

        if ($password !== $cpassword) {
            echo "<script>alert('Password and confirm password do not match')</script>";
        } else {
            $connection = new mysqli("localhost", "root", "", "webproject");
            $qCheck = "SELECT * FROM user WHERE stdname='$name'";
            $result = $connection->query($qCheck);

            if ($result->num_rows > 0) {
                echo "<script>alert('Username already exists')</script>";
            } else {
                $q1 = "insert into user (stdname, stdpassword, stdcpassword) values ('$name', '$password', '$cpassword')";

                if ($connection->query($q1) === TRUE) {
                    // Display success message with delay and redirect
                    echo "<script>
                            setTimeout(
                            function() 
                            {
                                alert('Signup Successfully');
                                window.location.href = 'index.php';
                            },
                            1000); // 1 second delay
                         </script>";
                } else {
                    echo "Error: " . $q1 . "<br>";
                }

                $connection->close();
            }
        }
    }
    ?>
</body>

</html>