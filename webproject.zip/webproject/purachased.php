<style>
    h2 {
        text-align: center;
        color: rgb(63, 77, 73);
        transition: 0.6s;
    }

    h2:hover {
        text-align: center;
        color: white;
        background-color: rgb(63, 77, 73);
        border: 0.5px solid whitesmoke;
        padding: 4px;
    }

    table {

        background-color: white;
        color: rgb(63, 77, 73);
        height: auto;
        width: 100%;
        transition: 1s;
    }

    table:hover {
        background-color: rgb(63, 77, 73);
        color: white;
        height: auto;
        width: 100%;
    }
</style>

<?php
    session_start();
    $stdid=$_SESSION["stdid"];
    if(isset($_SESSION["stdid"])==0){
        header("location:index.php");
    }

    echo "<h2>Purchased Properties</h2>";
    $connection = new mysqli("localhost", "root", "", "webproject");
    
    $q = "Select * from purchasedproperties where user_fk='$stdid'";
    $rs = $connection->query($q);
    
    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>" . "Date of Purchase" . "</th>";
    echo "<th>" . "Name of Property" . "</th>";
    echo "<th>" . "Total Amount paid" . "</th>";
    echo "<th>" . "Total Duration" . "</th>";
    echo "</tr>";
    
    while ($row = $rs->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["dateofpurcahse"] . "</td>";
        echo "<td>" . $row["propertyname"] . "</td>";
        echo "<td>" . $row["amountpaid"] . "</td>";
        echo "<td>" . $row["totalduration"] . "</td>";
        echo "</tr>";
    }
    
    $totalpurchaseQuery = "select COUNT(*) AS totalpurchases from purchasedproperties where user_fk='$stdid'";
    $totalpurchaseResult = $connection->query($totalpurchaseQuery);
    $totalpurchaseRow = $totalpurchaseResult->fetch_assoc();
    $totalpurchaseCount = $totalpurchaseRow['totalpurchases'];
    
    echo "<p><b>Total Purchased Properties:</b><b>&nbsp;&nbsp;" . $totalpurchaseCount . "</b></p>";
    
    echo "</table>";

?>