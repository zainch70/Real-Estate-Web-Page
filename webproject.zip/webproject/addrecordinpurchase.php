<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adding Record in Purchaes Properties</title>
    <style>
        h2 {
            text-align: center;
            color: rgb(63, 77, 73);
            transition: 0.6s;
        }

        h2:hover {
            text-align: center;
            color: white;
            background-color: rgb(63, 77, 73);
            border: 0.5px solid whitesmoke;
            padding: 4px;
        }

        table {

            background-color: white;
            color: rgb(63, 77, 73);
            height: 50vh;
            width: 100%;
            transition: 1s;
        }

        table:hover {
            background-color: rgb(63, 77, 73);
            color: white;
            height: 50vh;
            width: 100%;
        }

        #sub {
            margin-left: 50%;
        }
    </style>
</head>

<body>
    <?php
    if (isset($_SESSION["stdid"]) == 1) {
        header("location:index.php");
    }
    ?>
    
    <h2>Add Records In Purchase Properties</h2>
    <form action="addrecordinpurchase.php" method="POST">
        <table border="1">
            <tbody>
                <tr>
                    <td>Date of Purchase</td>
                    <td><input type="date" name="dateofpurcahse" required></td>
                </tr>
                <tr>
                    <td>Name of Property</td>
                    <td><input type="text" name="propertyname" placeholder="Type Propertyname " required></td>
                </tr>
                <tr>
                    <td>Total Amount Paid</td>
                    <td><input type="number" min="0" max="10000000" name="amountpaid" placeholder="Amount Paid"
                            required></td>
                </tr>

                <tr>
                    <td>Total Area</td>
                    <td><input type="text" name="totalarea" placeholder="Total Area" required></td>
                </tr>

                <tr>
                    <td colspan="2"><input type="submit" value="Submit" id="sub"></td>
                </tr>
            </tbody>
        </table>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        session_start();

        $dateofpurchase = $_POST["dateofpurcahse"];
        $propertyname = $_POST["propertyname"];
        $amountpaid = $_POST["amountpaid"];
        $totalarea = $_POST["totalarea"];

        if (isset($_SESSION['stdid'])) {
            $stdid = $_SESSION["stdid"];
        }

        $connection = new mysqli("localhost", "root", "", "webproject");
        $qCheck = "select * from purchasedproperties where propertyname='$propertyname'";
        $result = $connection->query($qCheck);

        if ($result->num_rows > 0) {
            echo "<script>alert('Property already Purchased')</script>";
        } else {
            $q1 = "insert into purchasedproperties(dateofpurcahse,propertyname,amountpaid,totalduration,totalarea,user_fk) values ('$dateofpurchase','$propertyname','$amountpaid','1 month','$totalarea','$stdid')";

            if ($connection->query($q1) == TRUE) {
                echo "<script>
                 setTimeout(function() 
                 {
                alert('Data inserted Succesfully in Purchased Properties');
                 }, 1000); 
                </script>";
            } else {
                echo "Error";
            }
        }
    }
    ?>
</body>

</html>