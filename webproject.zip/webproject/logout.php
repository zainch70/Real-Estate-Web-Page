<?php
session_start();
session_unset();
session_destroy();

if(isset($_SESSION["stdid"])==0){
    header("location:index.php");
}
?>