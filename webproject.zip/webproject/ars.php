<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add record in sale properties</title>
    <style>
        table {

            background-color: white;
            color: rgb(63, 77, 73);
            height: 70px;
            width: 35%;
            transition: 1s;
        }

        table:hover {
            background-color: rgb(63, 77, 73);
            color: white;
            height: 70px;
            width: 35%;
        }

        #sub {
            text-align: center;
        }
    </style>
</head>

<body>
    <?php

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        session_start();
        
        if (isset($_SESSION["stdid"])){
            $stdid = $_SESSION["stdid"];
        }

        $nameofproperty = $_POST["nameofproperty"];
        $dateofsale = $_POST["dateofsale"];
        $sellingamount = $_POST["sellingamount"];
        $amountreceived = $_POST["amountreceived"];

        $connection = new mysqli("localhost", "root", "", "webproject");
        $query = "select amountpaid from purchasedproperties where propertyname = '$nameofproperty' and user_fk='$stdid'";
        $result = $connection->query($query);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $amountpaid = $row["amountpaid"];
            $totalprofit = $sellingamount - $amountpaid;
        }

        if ($amountreceived < $sellingamount) {
            echo '<form action="nextdate.php" method="POST">';
            echo '<table border="1">';
            echo '<tr>';
            echo '<td>Next Date</td>';
            echo '<td><input type="text" name="nextdate" placeholder="yyyy-mm-dd" pattern="\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2]\d|3[0-1])" required></td>';
            echo '</tr>';
            // Pass other data as hidden fields
            echo '<input type="hidden" name="nameofproperty" value="' . htmlspecialchars($nameofproperty) . '">';
            echo '<input type="hidden" name="dateofsale" value="' . htmlspecialchars($dateofsale) . '">';
            echo '<input type="hidden" name="sellingamount" value="' . htmlspecialchars($sellingamount) . '">';
            echo '<input type="hidden" name="amountreceived" value="' . htmlspecialchars($amountreceived) . '">';
            echo '<tr>';
            echo '<td colspan="2" id="sub"><input type="submit" value="submit"></td>';
            echo '</tr>';
            echo '</table>';
            echo '</form>';
        } else {
            // Insert into saleproperties if no need for next date input
            $q1 = "insert into saleproperties (propertyname, dateofsale, sellingamount, amountreceived, totalprofit,nextdate,user_fk) 
                   values ('$nameofproperty', '$dateofsale', '$sellingamount', '$amountreceived', '$totalprofit','NULL','$stdid')";

            if ($connection->query($q1) === TRUE) {
             header("location:dashboard.html");
             exit();
            } else {
                echo "Error: " . $q1 . "<br>";
            }
        }

        $connection->close();
    }
    ?>

</body >

</html>