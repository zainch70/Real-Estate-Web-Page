<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Process Next Date</title>
</head>

<body>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nameofproperty = $_POST["nameofproperty"];
        $dateofsale = $_POST["dateofsale"];
        $sellingamount = $_POST["sellingamount"];
        $amountreceived = $_POST["amountreceived"];
        $nextdate = $_POST["nextdate"];

        $connection = new mysqli("localhost", "root", "", "webproject");

        // Check if property exists in purchasedproperties table
        $query = "select amountpaid from purchasedproperties where propertyname = '$nameofproperty'";
        $result = $connection->query($query);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $amountpaid = $row["amountpaid"];
            $totalprofit = $sellingamount - $amountpaid;
        }

        $q1 = "insert into saleproperties (propertyname, dateofsale, sellingamount, amountreceived, totalprofit, nextdate) 
               values ('$nameofproperty', '$dateofsale', '$sellingamount', '$amountreceived', '$totalprofit', '$nextdate')";

        if ($connection->query($q1) === TRUE) {
            header("location:dashboard.html");
            exit();
        } else {
            echo "Error: " . $q1 . "<br>";
        }

        $connection->close();
    } else {
        echo "Invalid request";
    }
    ?>

</body>

</html>