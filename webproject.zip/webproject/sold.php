<style>
    h2 {
        text-align: center;
        color: rgb(63, 77, 73);
        transition: 0.6s;
    }

    h2:hover {
        text-align: center;
        color: white;
        background-color: rgb(63, 77, 73);
        border: 0.5px solid whitesmoke;
        padding: 4px;
        padding: 4px;
    }

    table {

        background-color: white;
        color: rgb(63, 77, 73);
        height: auto%;
        width: 100%;
        transition: 1s;
    }

    table:hover {
        background-color: rgb(63, 77, 73);
        color: white;
        height: auto;
        width: 100%;
    }

    p {
        color: rgb(63, 77, 73);
    }

    #log {
        background-color: rgb(63, 77, 73);
        color: white;
        padding: 7px 15px 7px 13px;
        text-decoration: none;
        border-radius: 20px;
    }

    #log:hover {
        background-color: rgb(63, 77, 73);
        color: white;
        padding: 8px 18px 8px 18px;
        text-decoration: none;
        border-radius: 20px;
        transition: 0.4s;
    }

    #logdiv {
        margin-top: 20px;
        text-align: right;
        margin-right: 30px;
    }
</style>
<?php
session_start();
$stdid = $_SESSION["stdid"];

if (isset($_SESSION["stdid"]) == 0) {
    header("location:index.php");
}


echo "<div id='logdiv'><a href='logout.php'id='log'>Logout</a></div>";
echo "<h2>Sold Properties</h2>";
echo "<table border='1'>";
echo "<tr>";
echo "<th>Date of Purchase</th>";
echo "<th>Date of Sale</th>";
echo "<th>Name of Property</th>";
echo "<th>Total Amount received</th>";
echo "<th>NextDate</th>";
echo "<th>Total Profit</th>";
echo "</tr>";

$connection = new mysqli("localhost", "root", "", "webproject");

$q = "select p.dateofpurcahse,s.dateofsale,p.propertyname,s.amountreceived,s.nextdate,s.totalprofit from purchasedproperties p,saleproperties s where p.propertyname=s.propertyname and p.user_fk='$stdid'";

$result = mysqli_query($connection, $q);

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . $row["dateofpurcahse"] . "</td>";
    echo "<td>" . $row["dateofsale"] . "</td>";
    echo "<td>" . $row["propertyname"] . "</td>";
    echo "<td>" . $row["amountreceived"] . "</td>";
    echo "<td>" . $row["nextdate"] . "</td>";
    echo "<td>" . $row["totalprofit"] . "</td>";
    echo "</tr>";
}

echo "</table>";
$totalSalesQuery = "select COUNT(*) AS totalsales from saleproperties where user_fk='$stdid'";
$totalSalesResult = $connection->query($totalSalesQuery);
$totalSalesRow = $totalSalesResult->fetch_assoc();
$totalSalesCount = $totalSalesRow['totalsales'];

echo "<p><b>Total Sold Properties:</b><b>&nbsp;&nbsp;" . $totalSalesCount . "</b></p>";

$connection->close();
?>