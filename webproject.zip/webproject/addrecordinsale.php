<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adding Record in Purchaes Properties</title>
    <style>
        h2 {
            text-align: center;
            color: rgb(63, 77, 73);
            transition: 0.6s;
        }

        h2:hover {
            text-align: center;
            color: white;
            background-color: rgb(63, 77, 73);
            border: 0.5px solid whitesmoke;
            padding: 4px;
        }

        #tab1 table {

            background-color: white;
            color: rgb(63, 77, 73);
            height: auto;
            width: 100%;
            transition: 1s;
        }

        #tab1 table:hover {
            background-color: rgb(63, 77, 73);
            color: white;
            height: auto;
            width: 100%;
        }

        p {
            color: rgb(63, 77, 73);
        }

        #tab2 table {

            background-color: white;
            color: rgb(63, 77, 73);
            height: 70px;
            width: 70%;
            transition: 1s;
        }

        #tab2 table:hover {
            background-color: rgb(63, 77, 73);
            color: white;
            height: 70px;
            width: 70%;
        }

        #tab3 table {

            background-color: white;
            color: rgb(63, 77, 73);
            height: 70px;
            width: 70%;
            transition: 1s;
        }

        #tab3 table:hover {
            background-color: rgb(63, 77, 73);
            color: white;
            height: 70px;
            width: 70%;
        }

        #tab3 input {
            width: 70%;
        }

        td #separatestyle {
            width: 10%;
            margin-left: 50%;
            margin-top: 1%;
            margin-bottom: 1%;
        }
    </style>
</head>

<body>
    <?php
    echo "<h2>Purchased Properties Given Below Select 1 To Be Sale</h2>";
    session_start();

    if(isset($_SESSION["stdid"])==0){
        header("location:index.php");
    }

    // if (isset($_SESSION['stdid'])){
        $stdid = $_SESSION["stdid"];
    // }

    $connection = new mysqli("localhost", "root", "", "webproject");
    $totalpurchaseQuery = "select COUNT(*) AS totalpurchases from purchasedproperties where user_fk='$stdid'";
    $totalpurchaseResult = $connection->query($totalpurchaseQuery);
    $totalpurchaseRow = $totalpurchaseResult->fetch_assoc();
    $totalpurchaseCount = $totalpurchaseRow['totalpurchases'];
    
    echo "<p><b>Total Purchased Properties:</b><b>&nbsp;&nbsp;" . $totalpurchaseCount . "</b></p>";
    $q = "Select * from purchasedproperties where user_fk='$stdid'";
    $rs = $connection->query($q);

    echo "<div id='tab1'>";
    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>Date of Purchase</th>";
    echo "<th>Name of Property</th>";
    echo "<th>Total Amount paid</th>";
    echo "<th>Total Area</th>";
    echo "</tr>";

    while ($row = $rs->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["dateofpurcahse"] . "</td>";
        echo "<td>" . $row["propertyname"] . "</td>";
        echo "<td>" . $row["amountpaid"] . "</td>";
        echo "<td>" . $row["totalarea"] . "</td>";
        echo "</tr>";
    }

    echo "</table>";
    echo "</div>";

    echo "<div id='tab2'>";
    echo "<br><br>";
    echo "<form action='addrecordinsale.php' id='nofproperty' method='POST'>";
    echo "<table>";
    echo "<tr>";
    echo "<td><b>Name of Property:</b></td>";
    echo "<td><input type='text' name='nameofproperty' placeholder='Property Name To Be Sale'></td>";
    echo "<td><input type='submit' value='Add Additional Record'></td>";
    echo "</tr>";
    echo "</table>";
    echo "</form>";
    echo "</div>";
    ?>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
        $connection = new mysqli("localhost", "root", "", "webproject");
        $nameofproperty = $_POST["nameofproperty"];

        $q = "SELECT * FROM purchasedproperties WHERE propertyname='$nameofproperty' and user_fk = '$stdid'";
        $result = $connection->query($q);
        $count = mysqli_num_rows($result);

        if ($count > 0) {
            echo "<h2>Add Additional Records Below</h2>";
            echo "<script>
                    setTimeout(function() {
                        alert('Property Found');
                   }, 500); // 0.5 second delay
                </script>";

            echo "<div id='tab3'>";
            echo "<form action='ars.php' method='POST'>";
            echo "    <table border='1'>
                        <tbody>
                            <tr>
                                <td>Date of Sale</td>
                                <td><input type='date' name='dateofsale' required></td>
                            </tr>
                            <tr>
                                <td>Total Selling Amount</td>
                                <td><input type='number' min='0' name='sellingamount' placeholder='Enter Selling Amount' required></td>
                            </tr>
                            <tr>
                                <td>Received Amount</td>
                                <td><input type='number' min='0' name='amountreceived' placeholder='Received Amount' required></td>
                            </tr>
                            <tr>
                                <td colspan='2'><input type='submit' value='Submit' id='separatestyle'></td>
                            </tr>
                        </tbody>
                    </table>";
            echo "<input type='hidden' name='nameofproperty' value='" . htmlspecialchars($nameofproperty) . "'>";
            echo "</form>";
            echo "</div>";
        } else {
            echo "<script>
                    setTimeout(function() {
                        alert('Property Not Found With that name');
                        window.location.href = 'addrecordinsale.php';
                    }, 500); // 0.5 second delay
                </script>";
        }

        $connection->close();
    }
    ?>
</body>

</html>